import urllib
import urllib.parse
import urllib.request
from urllib.parse import urlparse, parse_qs
import subprocess
import pickle
import re
import os
import sys
import re
import shlex
import string

# describeWindows.py - a python3 script for presenting all the Windows executanles/tasks.
# All arguments have been validated by the describeWindows parent shell script.

# Arguments are passed using URL forms data arguments.
# Supported arguments are as described below:
# sysref      presents the SYSREF used to access the sys.conf file making use the
#             functions provided in the sys.function file or is one of our special
#             intercept values used for accessing manual files.
# command     the command to be decribed, It can be a search term.
# searchterm  Optional. If present indicates command is a search term.
# color       For search match how to present
# rescan      If selected means to rescan descriptions
# audit       Audit command descriptions checking if they are are correct
# trace       Enable trace to stderr of rescan
# criteria    'all', 'help', 'ques' limit escriptions to that criteria,
# not        if provided and "y" do not present descriptions for the given criteria
# novm        Do no communication with Windows VM. Merge both Windows 10 & 11 confiurations.
#             This means no 'help CMD' or 'CMD /?' available. Just HTML.
#             This turns off the rescan and audit arguents.
# view10      Select View Windows 10
# view11      Select View Windows 11


# Present our file browsing links.
script_filename = os.path.basename(__file__)
base = os.path.basename(script_filename)
print("<div align=right><font size=-2><a href=/cgi-bin/showfile?file="+script_filename+">"+base+"</a></font></div>")

# Get invoking script name
script_name = os.getenv("SCRIPT_NAME")

# Bring in the URL forms data arguments we use.
link=os.getenv("REQUEST_URI")
parsed_url = urlparse(link)
form = parse_qs(parsed_url.query)

# where we save cmd_dict for speed. Changed based on Windows release
config_file = ""

# Save files based on Windows release
config_win10 = "files/windows.cmd.win10.cmd_dict.data"
config_win11 = "files/windows.cmd.win11.cmd_dict.data"

sysref = ""
sysref_arg = False
if "sysref" in form:
    sysref = form["sysref"][0]
    sysref_arg = True
else:	# if not there assume novm
    form["novm"] = "y"
command = ""
if "command" in form:
    command = form["command"][0].strip()

searchterm = False
if "searchterm" in form:
    searchterm = True
rescan = False
if "rescan" in form:	# force a redescovery of everything
    rescan = True
audit = False
if "audit" in form:	# audit executable/task references
#    print("audit")
    audit = True
if "trace" in form:
    controls_trace = True	# control for trscing to stderr
else:
    controls_trace = False
if "criteria" in form:
    criteria = form["criteria"][0]
else:
    criteria = "all"
novm = False
novm_arg = ""
if "novm" in form:
    if len(form["novm"]) > 0:	# only set if there is a value
        novm = True
        sysref_arg = False
        novm_arg = "&novm=Y"
        # neither of these can be run
        rescan = False
        audit = False
else:
    novm = False
    novm_arg = ""
notcriteria = False
passon_not = "n"	# in command present description link
if "not" in form:
    passon_not = form["not"][0]
    if passon_not == "y":
        notcriteria = True

# Determine what release is presented
if "view10" in form:
    view10 = True
else:
    view10 = False
if "view11" in form:
    view11 = True
else:
    view11 = False
if view10 and view11:
    view_release="all"
if not view10 and not view11:
    view_release="all"
else:
    if view10 and not view11:
        view_release="10"
    if view11 and not view10:
        view_release="11"

# Done with URL parameters ===========================

def allowed_char(instr):
    ret  = ""
    for i in range(len(instr)):
        if instr[i].isalpha() or instr[i].isdigit() or instr[i] == "." or instr[i] == " ":
            ret = ret + instr[i]
    return ret

# Get system of execution if needed
sys_hostname = os.getenv("sys_hostname")

searchterm_string = allowed_char(command)
if command == "":	# empty means search everything
    searchterm = True
else:
    if len(searchterm_string) < 3:
        searchterm_string = ""

if searchterm:
    re_searchterm = "(%s)" % searchterm_string	# so it gets identified as a group in re.sub()
    re_searchterm = re.compile(re_searchterm, flags=re.IGNORECASE)
else:
    searchterm_string = ""

if searchterm and searchterm_string != "":
    docolorize = True
else:
    docolorize = False

if "color" in form:
    search_match_color = form["color"][0]
    
# Control for highlite of search results. Supported colors are shown below.
# Default is to present search matches as black bold underline.
# rer_ = RE Replacement.
# search_match_color="red"
try:
    if search_match_color == "red":
        rer_searchterm_colorize = r"<red><b><u>\1</u></b></red>"
    elif  search_match_color == "green":
        rer_searchterm_colorize = r"<green><b><u>\1</u></b></green>"
    elif search_match_color == "orange":
        rer_searchterm_colorize = r"<orange><b><u>\1</u></b></orange>"
    elif search_match_color == "blue":
        rer_searchterm_colorize = r"<blue><b><u>\1</u></b></blue>"
    elif search_match_color == "purple":
        rer_searchterm_colorize = r"<purple><b><u>\1</u></b></purple>"
    else:
        rer_searchterm_colorize = r"<black><b><u>\1</u></b></black>"
except NameError:
     rer_searchterm_colorize = r"<red><b><u>\1</u></b></red>"

if sysref != "":
    # If running with sysref means we are communicating with a VM.
    # Bring in sys.conf values. Bring in all '_SYSREF_'
    # values, changing '_SYSREF_' to just '_'.
    # So, for example, 'sys_windows_platform' becomes 'sys_platform' here in python
    sys_platform = ""
    lines = (open("sys.conf", "r")).readlines()
    for i in range(len(lines)):
        execline = False
        repl =  "_" + sysref + "_"
        if repl in lines[i]:
            lines[i] = lines[i].replace(repl, "_")
            execline = True
            exec(lines[i])

    # Set up the means of communication
    windows_cmd_prefix = "sshpass -p '"+sys_passwd+"' /usr/bin/ssh -o LogLevel=ERROR -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no "+sys_userid+"@"+sys_hostname + " 2>/dev/null "
else:
    windows_cmd_prefix = ""

# Sometimes subprocess.Popen() results in a list of bytes. Convert if needed.
def listbytes2utf8(list):
    try:
        if len(list) > 0:
            if "test" in list[0]:
                pass
    except:
        for i in range(len(list)):
            list[i] = list[i].replace(b'\xa9', b'&copy;') 	# replsce copyright char
            list[i] = list[i].replace(b'(C)', b'&copy;') 	# this too
            list[i] = list[i].replace(b'( C )', b'&copy;') 	# this too
            list[i] = list[i].replace(b'\x93', b'&ldquo;') 	# replsce left double quotation mark char
            list[i] = list[i].replace(b'(R)', b'&reg;') 	# ascii registered

            list[i] = list[i].replace(b'\x94', b'&ldquo;') 	# replsce right double quotation mark char
            list[i] = str(list[i], "utf-8") # convert
    return list

re_comment = re.compile("#.*$")

# strings in responses we consider as a connection disconnect
disconnect_reasons = [
    "Connection reset by peer",
    "timeout specified has expired" ,
    "failed reading from PIPE",
    "Permission denied",
    "Connection refused"
]

# Apply color to internal flag
def color_internal_flag(instr):
    return instr.replace("**", "<brown><u>**</u></brown>")


# Windows executable suffixes and how we find/handle them
windows_suffix =  ['.COM', '.EXE', '.BAT', '.CMD', '.CPL', '.VBS', '.VBE', '.JS', '.JSE', '.WSF', '.WSH', '.MSC']
compiled_suffix = []
for asuffix in windows_suffix:
    compiled_suffix.append(re.compile("\\" + asuffix + "$", flags=re.IGNORECASE))
windows_where_cmd = "where"
for asuffix in  windows_suffix:
    windows_where_cmd = windows_where_cmd + " *" + asuffix
windows_where_cmd = windows_where_cmd + " 2>NUL"
def remove_suffix(name):
    for asuffix in compiled_suffix:
        if asuffix.search(name):
            name = re.sub(asuffix, "", name)
            break
    return name


# What is checked in Synopsis for Windows release appropriate items
new_in_win11_str = "NEW in win11"
not_in_win11_str = "NOT in win11"

# Run a Windows command, Return results
def runwindowscmd(command):
    cmd = windows_cmd_prefix  + command
    args = shlex.split(cmd)
    proc = subprocess.Popen(args, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    lines = proc.stdout.readlines()
    lines = listbytes2utf8(lines)
    proc.stdout.close()
    return lines

# for the cmd_dict list values, the index positions for list information.
help_idx = 0	# help CMD True/False
ques_idx = 1	# CMD /? True/False
html_idx = 2	# CMD.html True/False
syno_idx = 3	# Synopsis string

# format for path to explaination files
files_html_path_format = "files/%s.html"

# checkmark for lists
checkmark = "<center><red><b>&#x2713;</b></red></center>"

# Main processing from here =====================================================

# Function that prints a message with s bsck button
def print_back(message):
    print("""
    <table width=100%><tr><td valign=center width=100><form><input type=button value=Back onclick="history.back()"></form></td>
    <td valign=center>""" + message + "</td></tr></table>")


if novm:	# running without a VM

    vm_connected = False
#    windows_release = "??"	# placekeeper
    # What is shown at top of page
    if view_release == "all":
        page_header= "<p><h1><green>Windows 10 & 11 Combined</green></font></h1>"
    elif view_release == "10":
        page_header= "<p><h1><green>Windows 10</green></font></h1>"
    elif view_release == "11":
        page_header= "<p><h1><green>Windows 11</green></font></h1>"
else:
    # communicating with a VM
    # Determine release of Windows in the VM we are working with if connecting to a VM
    # print("checking windows version")
    vm_connected = True	# until otherwise shown
    cmd = 'C:/Windows/System32/cmd.exe /c "where %s 2>&1"' % "wmic"
    lines = runwindowscmd(cmd)
#    print("Run: ", cmd, file=sys.stderr)
#    print("Got: ", lines, file=sys.stderr)
    if "Could not find files" in lines[0]:
        windows_release = 11	# wmic not there in Windows 11
        config_file = config_win11
    elif "System32" in lines[0]:	# in pathname
        windows_release = 10
        config_file = config_win10
    else:
        print("<h2><red>ERROR: Lost connection to %s - %s</red></h2>" % (sys_hostname, lines[0].strip()))
        exit(1)

    # Load our saved memory
    if not os.path.exists(config_file):
        print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
        exit(1)
    file = open(config_file, "rb")
    try:
        cmd_dict = pickle.load(file)
    except:
        print("<red>ERROR File mslformed %s</red>" % config_file)
        exit(1)
    file.close()


    # What is shown at top of page
    page_header = "<green><h1>Accessing Windows %s (%s)</h1></green>" % (windows_release, sys_hostname)

# First off if we are doing a rescan do it now.

# Routines for rescan for cmd_dict contents:

# Learn the HTML files and accumulate cmd_dict
def scan_html():
    dirent = os.scandir("files")	# below cgi-bin directory
    for afile in dirent:
        if not afile.is_file():
            continue
        if ".html"  not in afile.name:
            continue
        filecmd = afile.name.replace(".html", "")
        filecmd = filecmd.upper()

        afile = open("files/%s" % afile.name, "r")
        firstline = afile.readline().strip()
        words = firstline.strip().split()
        desc = ""
        textcmd = ""
        if len(words) > 0:
            textcmd = words[0].upper().replace("<", "&lt;").replace(">", "&gt;")
            if len(words) > 1:
                if words[1] == "-":	# maybe contains "CMD - Synopsis"
                    if len(words) > 2:
                        for j in range(2, len(words)):
                            desc = desc + " " + words[j]
                    else:		# just trailing '-'
                        errors.append("File %s First line does not have Synopsis" % afile.name)
                else:		# msybe just CMD Synopsis
                    if len(words) > 1:
                        for j in range(1, len(words)):
                            desc = desc + " " + words[j]
                    else:		# nothing after CMD                          
                        errors.append("File %s First line does not have Synopsis" % afile.name)
            else:
                errors.append("File %s First line does not have Synopsis" % afile.name)
        else:
            errors.append("%s: First line empty" % afile.name)
                
        if filecmd != textcmd:
            errors.append("%s: First word of first line '%s' does not match filename '%s' preceeding '.html'" \
                          % (afile.name, textcmd, filecmd))

        afile.close()

        # Only remember what is appropriate for Windows release
        if windows_release == 10 and new_in_win11_str in desc:
            continue
        if windows_release == 11 and not_in_win11_str in desc:
            continue

        cmd_list =  [False, False, True, desc]
        cmd_dict[filecmd] = cmd_list	# populate for other routines to fill in


# Get help from Windows - fill in cmd_dict which should be populated from HTML files above
def load_help():
    cmd = "cmd /c help"
    lines = runwindowscmd(cmd)
    for i in range(len(lines)):
        if re.search("^    ", lines[i]):
            lines[i-1] = lines[i-1] + lines[i]
            lines[i] = ""
            for i in range(len(lines)):
                if "For more information" in lines[i]:
                    continue
                lines[i] = lines[i].rstrip()	# just trailing things like line termination characters
                if lines[i] == "":
                    continue
                if re.match("^   ", lines[i]):	# folded line of command description
                    continue
                words = lines[i].split()
                acommand = words[0].upper()	# there are always words in a line
                if windows_release == 10 and acommand == "GRAFTABL":	# not there
                    continue
                if windows_release == 11 and acommand == "WMIC":	# not there
                    continue
                if acommand in cmd_dict:
                    cmd_dict[acommand][help_idx] = True	# This has help
                else:
                    errors.append("Windows help for command '%s' does not have a HTML file" % acommand)


# Blend in command /? inforation - again expecting  HTML files
def load_ques():
    infile = "files/windows.cmd.question.txt"
    if os.path.exists(infile):
        file = open(infile, "r")
        lines = file.readlines()
        for i in range(len(lines)):
            lines[i] = re.sub(re_comment, "", lines[i])	# trim comments
            words = lines[i].split()
            if len(words) > 0:
                acommand = words[0].upper()	# only first word used

                # Only learn what is appropriate for the Windows release
                if acommand not in cmd_dict:
                    continue

                cmd_dict[acommand][ques_idx] = True	# This supports /? argument

        file.close()


# Learn all eecutable files in search path from the Windows VM and load paths in all_executable dictionary
def find_all_executable():
    # overt execution pf CMD insures registry AutoRun is invoked
    cmd = "cmd /c " + windows_where_cmd
    if controls_trace:
        print("Run:",  cmd, file=sys.stderr)
    lines = runwindowscmd(cmd)
    if controls_trace:
        print("Got: %d executable paths" % len(lines), file=sys.stderr)
    for aline in lines:
        if "cygwin64" in aline:	# ignore CYGWIN
            continue
        aline = aline.strip()
        for bad in disconnect_reasons:
            if bad in aline :
                if controls_trace:
                    print("Lost VM connection - ", aline, file=sys.stderr)
                    print("raise ConnectionError", file=sys.stderr)
                raise ConnectionError(aline)

        if aline == "":
            continue
        basename =  os.path.basename(aline.replace("\\", "/"))
        basename = basename.upper()
        basename = remove_suffix(basename)
        path = ""
        # Dereference user path
        path = re.sub("^C:.Users.[-_A-Za-z0-9]+", r"%HOMEPATH%", aline, flags=re.IGNORECASE)

#        print("For %s remembering %s" % (basename, path), file=sys.stderr)
        if basename in all_executable:
            all_executable[basename].append(path)	# remember
        else:
            all_executable[basename] = [ path ]		# inital list of 1

# End of rescan routines used during a rescan


if rescan or not os.path.exists(config_file) and not novm:	# do this if asked or needed - rescan is False if novm set

    # Always log this
    if controls_trace:
        print("Starting rescan of descriptions from VM running Windows %s" % windows_release, file=sys.stderr)

    # Starting out or reloading and we must (re)learn cmd_dict from the config_file set above
    cmd_dict = dict()
    errors = []

    try:

        # Learn what executables/tasks we present by scanning for .html files populating cmd_dict
        scan_html()

        # Learn all executable paths into dictionary all_executable
        all_executable = dict()
        find_all_executable()

#        print("<pre>")
#        print(all_executable)
#        print("</pre>")

        if len(errors) == 0:	# no error in find_all_executable()
            show_path_fmt = "\n<li>[<font size=-1><green>%s</green></b></font>]"
            for acmd in cmd_dict:
                if "**" in cmd_dict[acmd][syno_idx]:
                    cmd_dict[acmd][syno_idx] = cmd_dict[acmd][syno_idx] + show_path_fmt % "internal command/task"
                elif acmd in all_executable:
                    for apath in all_executable[acmd]:	# add in all found paths
                        cmd_dict[acmd][syno_idx] = cmd_dict[acmd][syno_idx] + show_path_fmt % apath
                else:
                    errors.append("%s.html: executable not found %s" % (acmd, acmd))

        if controls_trace:
            print("Done with learning executable locations", file=sys.stderr)

        # Now blend in list from Windows help command
        load_help()

        # Finally blend in command /? inforation. From years ago old CGI script.
        load_ques()
    except ConnectionError as e:
        if controls_trace:
            print("except ConnectionError caught", file=sys.stderr)
        vm_connected = False
        reason = str(e)
        errors.append("Lost connection to %s - %s" % (sys_hostname, reason))

    # all done with initial load or rescan

    if len(errors) > 0:
        print("<h1>Results of rescan of descriptions for VM running '%s' (Windows %s)</h1>" % (sys_hostname, windows_release))
        print_back("<red><h1>ERROR(S): Encountered performing rescan</h1></red>")
        if controls_trace:
            print("ERROR(S): Encountered performing rescan", file=sys.stderr)
        print("<font size=+2>")
        for aerror in errors:
            print("<br>&bull;<red> ERROR: ", aerror, "</red>")
            if controls_trace:
                print(aerror, file=sys.stderr)
        print("<h3>DID NOT save description configuration</h3>")
        print("</font>")
        if controls_trace:
            print("DID NOT save description configuration", file=sys.stderr)
        print("</red><h2>Correct error(s) and retry - exiting</h2>")
        if controls_trace:
            print("Exiting", file=sys.stderr)
        exit(0)		# do not continue until errors corrected

    # finally save for speed and reuse
    try:
        file = open(config_file, "wb")
        pickle.dump(cmd_dict, file)
        msg = "<h2>Saving description configuration to %s</h2>" % os.path.realpath(config_file)
        print_back(msg)
        if controls_trace:
            print("Saving description configuration to %s" % os.path.realpath(config_file), file=sys.stderr)
        print("<h2>Exiting</h2>")
        file.close()
    except (IOError, OSError):
        print("<h1>Permission denied writing %s</h1>" % os.path.realpath(config_file))
        if controls_trace:
            print("Permission denied writing %s" % os.path.realpath(config_file), file=sys.stderr)

    # Always log this
    if controls_trace:
        print("Done with rescan of descriptions from VM running Windows %s" % windows_release, file=sys.stderr)
    exit(0)	# Do not continue

if novm:
    if view_release == "all":
        # merge Windows 10 & 11 for presentation
        bad = False

        config_file = config_win10
        if not os.path.exists(config_file):
            print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
            bad = True
        else:
            file = open(config_file, "rb")
            try:
                cmd_dict = pickle.load(file)
            except:
                print("<red>ERROR File mslformed %s</red>" % config_file)
                bad = True
        if not bad:
            file.close()

        config_file = config_win11
        file = open(config_file, "rb")
        if not os.path.exists(config_file):
            print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
            bad = True
        else:
            file = open(config_file, "rb")
            try:
                win11_dict = pickle.load(file)
            except:
                print("<red>ERROR File mslformed %s</red>" % config_file)
                bad = True
        if not bad:
            file.close()

#    print("blending dict")
        for win11_cmd in win11_dict:
            if win11_cmd not in cmd_dict:
                cmd_dict[win11_cmd] = win11_dict[win11_cmd]
        if bad:
            print("<red>Run Rescan descriptions for the affected Windows release(s)<br>Exiting</red>")
            exit(1)
    elif view_release == "10":
        bad = False
        config_file = config_win10
        if not os.path.exists(config_file):
            print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
            bad = True
        else:
            file = open(config_file, "rb")
            try:
                cmd_dict = pickle.load(file)
            except:
                print("<red>ERROR File mslformed %s</red>" % config_file)
                bad = True
        if not bad:
            file.close()
            for entry in cmd_dict:	# remove release specific identifiers
                cmd_dict[entry][syno_idx] = cmd_dict[entry][syno_idx].replace(not_in_win11_str, "")
    elif view_release == "11":   
        bad = False
        config_file = config_win11
        if not os.path.exists(config_file):
            print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
            bad = True
        else:
            file = open(config_file, "rb")
            try:
                cmd_dict = pickle.load(file)
            except:
                print("<red>ERROR File mslformed %s</red>" % config_file)
                bad = True
        if not bad:
            file.close()
            for entry in cmd_dict:	# remove release specific identifiers
                cmd_dict[entry][syno_idx] = cmd_dict[entry][syno_idx].replace(new_in_win11_str, "")


# ============= Audit ===============      
if audit:	# Audit (validate) executable/task references - do nothing else

# Extract HTML anchor tag info from a line. Assume one anchor per line.
# If found return array: [0] is href,  [1] is link text
# Return of None is no anchor found
    def extract_anchor(line):
        found = False
        locate = re.search("<a.*?</a>", line)	# search with "</a>" oresent
        if locate != None:
            found = True
        if not found:
            locate = re.search("<a.*", line)		# search without "</a>" oresent
            if locate != None:
                found = True
        if found:
            ret = list()
            match = locate.group()
            href = re.sub(".*href=", "", match)
            href = re.sub(">.*$", "", href)
            href_text = re.sub("^.*?>", "", line)
            href_text = re.sub("</a>.*", "", href_text)
            ret.append(href)
            ret.append(href_text)
            return ret
        return None


    print("<h1>Start of Audit for VM running Windows %s (%s)</h1>" % (windows_release, sys_hostname))

    errors = []

    print("<h3>Memory File</h3>")
    print("<b>", config_file, "</b>")

    if not os.path.exists(config_file):
        print("<red><h1>ERROR: File does not exist %s</red>" % config_file)
    else:
        file = open(config_file, "rb")
        try:
            cmd_dict = pickle.load(file)
        except:
            print("<red>ERROR File mslformed %s</red>" % config_file)

    print("<h3>Communication with VM</h3>")
    print("<b>", windows_cmd_prefix, "</b>")

    print("<h3>Checking configuration counts based on Windows release</h3>")

    chrcnt = dict()	# where we keep character counts
    alpha = set()
    for c in list(string.ascii_uppercase):
        chrcnt[c] = 0

    for acommand in sorted(cmd_dict):
        # Handle 1st char for total counts
        c = acommand[0]
        if c.isalpha():
            chrcnt[c] = chrcnt[c] + 1
            alpha.add(c)

    dict_cnt = 0
    file_cnt = 0
    for acmd in cmd_dict:
        dict_cnt = dict_cnt + 1
    dirent = os.scandir("files")	# below cgi-bin directory
    for afile in dirent:
        if not afile.is_file():
            continue
        if ".html"  not in afile.name:
            continue
        afile = open("files/%s" % afile.name, "r")
        firstline = afile.readline().strip()

        # Only count what is appropriate for Windows release
        if windows_release == 10 and new_in_win11_str in firstline:
            continue
        if windows_release == 11 and not_in_win11_str in firstline:
            continue

        file_cnt = file_cnt + 1
        afile.close()
    print("<b>%d</b> entries in executable/task dictionary" % dict_cnt)
    print("<br><b>%d</b> .html files" % file_cnt)
    if dict_cnt != file_cnt:
        print("<h3>Numbers do not match - do refresh descriptions for this release</h3>")
    else:
        print("<h3>Numbers match - no need to refresh descriptions</h3>")

    print("<h3>Description entries based on 1st letter</h3>")
    print("<table border=1><tr>")
    for c in sorted(alpha):
        print("<td wodth=34>%s&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>%d<?td>" % (c, chrcnt[c]))
    print("</tr></table>")
    
    # Show errors
    if len(errors) > 0 :
        print("<h2>Errors:</h2>")
        for error in errors:
            print("<br>&bull<red>", error, "</red>")
    else:
        dirs = []
        cmd = "cmd /c " + windows_where_cmd
        print("<h3>Searching VM for executable files with <pre>'%s'</pre></h3>" % cmd)
        lines = runwindowscmd(cmd)
        new_exe = []
        for aline in lines:
            if "cygwin64" in aline:	# ignore CYGWIN
                continue
            aline = aline.strip()
            if aline == "":
                continue
            aline = aline.replace("\\", "/")
            dirname = os.path.dirname(aline)
            if dirname not in dirs:
                dirs.append(dirname)
            basename =  os.path.basename(aline).upper().strip()
            basename = remove_suffix(basename)
            if basename in cmd_dict:
                continue
            new_exe.append(aline)

        print("<h3>Search Path learned from search:</h3>")
        for adir in dirs:
            print(adir.replace("/", "\\"), "<br>")

    print("<h3>%d count. All executable files in above search path without descriptions:</h3>" % len(new_exe))

    for aline in new_exe:
        aline = aline.rstrip().replace("/", "\\")
        print(aline, "<br>")

    # Now check the cache for running standalone
    help_cache = "files/help"	# directory
    ques_cache = "files/ques"	# directory
    help = []
    ques = []
    for acmd in sorted(cmd_dict):
        cmd_list = cmd_dict[acmd]
        if cmd_list[help_idx]:
            cache_file = "%s/%s" % (help_cache, acmd)
            if not os.path.exists(cache_file):       
                help.append(acmd)
        if cmd_list[ques_idx]:
            cache_file = "%s/%s" % (ques_cache, acmd)
            if not os.path.exists(cache_file):       
                ques.append(acmd)

    print("<h3>Cache executable descriptions required to be saved</h3>")
    print("help =============<br>", help)
    print("<br>ques ===========<br>", ques)

    print("<h3>Possibly malformed @ref(reference) rntries in .html files</h3>")
    badref = []
    entry_dict = dict()		# per-entry lists of contained @ref() occurrances. Populated for all.
    linux_dict = dict()		# description taken from Linux
    cntref_dict = dict()
    netref_dict = dict()	# Network Description href URL
    links = dict()	# <a href found
    noblank_link = list()	# links without " target=_blank "


    dirent = os.scandir("files")	# below cgi-bin directory
    for afile in dirent:
        if not afile.is_file():
            continue
        if ".html"  not in afile.name:
            continue
        entry = afile.name.replace(".html", "").upper()
        if entry not in cmd_dict:
            continue
        afile = open("files/%s" % afile.name, "r")
        lines = afile.readlines()
        filename = afile.name
        afile.close()
        entry_dict[entry] = []	# make sure this exists for everone.
        linux_desc = False
        for aline in lines:

            if "Linux Description" in aline:
                linux_dict[entry] = "Linux"
                continue

            if "@net(" in aline:
                aline = aline.strip()
                url = re.sub(r"@net\((.*)\)", r"\1", aline)
                if url == aline:
                    url = "<b>Syntax Error</b>"
                netref_dict[entry] = url

            # Present URL references
            anchor = extract_anchor(aline)
            if anchor != None:
                if " target=_blank " not in aline and entry not in linux_dict:
                    noblank_link.append("%s &rarr; %s" % (entry, aline))

                if entry not in links:
                    links[entry] = list()
                    links[entry].append("<green>"+anchor[0]+"</green><b> "+anchor[1]+"</b>")

            # From here on learning references
            if "@ref(" not in aline:
                continue
            while(True):
                if "@ref(" not in aline:
                    break
                locate = re.search(r"@ref\([A-Za-z0-9.;_-]+\)", aline)
                try:
                    match = locate.group()
                    aline = aline.replace(match, "")
                    reference = re.sub(r"@ref\(([A-Za-z0-9.;_-]+)\)", r"\1", match).lower()
                    reference_nosuffix = remove_suffix(reference).upper()
                    if reference_nosuffix not in cmd_dict:
                        badref.append(filename + "&rarr; @ref(%s[ERR_UNDEF])" % reference_nosuffix)
                    else:
                        if reference_nosuffix == filename.replace(".html", ""):
                            badref.append(filename + "&rarr; @ref(%s[ERR_SELF])" % reference_nosuffix)
                        else:
                            entry_dict[entry].append(reference)
                            if reference not in cntref_dict:
                                cntref_dict[reference] = 1
                            else:
                                cntref_dict[reference] = cntref_dict[reference] + 1
                except:
                    # mot found - not an error
                    # badref.append(filename)
                    break
    if len(badref) == 0:
        print("None found")
    else:
        badref = list(set(badref))
        badref.sort()
        for entry in badref:
            print(entry, "<br>")
        print("<p>Possibly malformed as they may be for a different release of Windows<br>or refresh descriptions needs to be run. ")

    print("<h3>Links without target=_blank</h3>")
    if len(noblank_link) == 0:
        print("None found")
    else:
        for bad in noblank_link:
            print(bad)

    print("<h3>%d entries for this release</h3>" % len(entry_dict))
    print("<h3>Release summary table</h3>")
    print("Per-entry list of @ref(refentry) instances")
    print("<br>&bull;&bull; <brown>URL</brown> Network Description link")
    print("<br>?? <green>URL</green> <b>link text</b> information link")
    print("<br>Entries that are <b>UNKNOWN</b> are identified")
    print("<br>Entries with <b>Linux Description</b> are identified.")
    print("<p>")
    print("<table border=1 width=100%><tr><th>Entry</th><td align=center>References</th></tr>")
    for entry in sorted(entry_dict):
        print("<tr><td>%s</td><td>" % entry)
        entry_dict[entry] = set(entry_dict[entry])
        for ref in entry_dict[entry]:
            thisref = remove_suffix(ref)
            upper_ref = thisref.upper()
            show_ref = ref
            if upper_ref not in cmd_dict:
                show_ref = "<b>%s[ERR_UNDEF]</b>" % ref
            if upper_ref == entry:
                show_ref = "<b>%s[ERR_SAME]</b>" % ref
            print(show_ref)

        # If this is UNKNOWN in the Synopsis say so and we are done with this one.
        if "UNKNOWN" in cmd_dict[entry][syno_idx]:
            print("<h2>UNKNOWN</h2></td></tr>")
            continue

        if entry in linux_dict:
            print("<h2>Linux Description</h2></td></tr>")
            continue

        # Put out Network Description if it is there
        if entry in netref_dict:
            print("<br>&bull;&bull;", "<brown>", netref_dict[entry], "</brown>")

        # Put out links if there are any
        if entry in links:
            for alink in links[entry]:
                print("<br> ??",  alink)

        print("</td></tr>")
    print("</table>")

    # Now check Microsoft A-Z command list
    url = "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands#command-line-reference-a-z"
    with urllib.request.urlopen(url) as response:
        html =  response.read().decode('utf-8')
        lines = html.split("\n")
        possible = list()
        for i in range(len(lines)):
            if "</a>" in lines[i] and "<code>" in lines[i] \
               and "data-linktype=" in lines[i] and len(lines[i]) < 80:
                ref = re.sub("^<li>.*<code>", "", lines[i])
                ref = re.sub("</code>.*$", "", ref)
                ref = ref.upper()
                if ref not in cmd_dict:
                    continue
                if ref in netref_dict:
                    continue
                possible.append(ref)
        print("<h3>Possible Network Description from", url, "</h3>")
        if len(possible) == 0:
            print("<p>None found")
        else:
            for aref in possible:
                print(aref, "<br>")

    # Now check SS64
    url = "https://ss64.com/nt/"
    with urllib.request.urlopen(url) as response:
        html =  response.read().decode('utf-8')
        lines = html.split("\n")
        possible = list()
        for i in range(len(lines)):
            if "<td><a href=" in lines[i]:
                if len(lines[i]) > 44:
                    continue
                ref = re.sub("^<td><a href=.*?>", "", lines[i])
                ref = re.sub("</a>.*$", "", ref)
                if ref not in cmd_dict:
                    continue
                if ref in netref_dict:
                    continue
                possible.append(ref)
        print("<h3>Possible Network Description from", url, "</h3>")
        if len(possible) == 0:
            print("<p>None found")
        else:
            for aref in possible:
                print(aref, "<br>")


    print("<h1>End of audit</h1>")


    exit(0)	# do no more with this

# ============ Done  with rescan and audit - Presenting descriptions =======================


# Table header for list of executables/tasks
table_header = """
<tr><thead>
<th align center width=320 style="white-space:nowrap"<b>Executable / Task</b></th>
<th align=center width=100 style="white-space:nowrap"><b>&nbsp;&nbsp;&nbsp;help cmd&nbsp;&nbsp;&nbsp;</b></th>
<th align=center width=100 style="white-space:nowrap"><b>&nbsp;&nbsp;&nbsp;cmd /?&nbsp;&nbsp;&nbsp;</b></th>
<th align=center width=800 style="white-space:nowrap"><b>Synopsis</b></th></tr>
</thead>
"""

if searchterm:	# scsnning for explainations
# Present browser page header
    print_back(page_header)
    found = []		# what we have found
    total_count = 0
    alpha = set()	# 1st char of entries set
    prevchar = ""	# last 1st char
    saw_int = False

    # Results are in lists. This allows counts to be presented before details.
    # Also allows for First Letter Links to be presented at the top.
    
    if notcriteria and criteria == "all":
        print("<h2>0 found. Origin criteria: all, excluding</h2>")
        print("<red><h2>Nothing found</h2></red>")
    else:
        full_list = []
        letter_list = []
        if docolorize or criteria != "all":
            cnt_type = "found"
        else:
            cnt_type = "count"
        entry_list = sorted(cmd_dict)

        for idx in range(len(entry_list)):
            acommand = entry_list[idx]
            cmd_list = cmd_dict[acommand]
            keep = True
            link_text = acommand
            syno = cmd_list[syno_idx]
            lookfor = searchterm_string.upper()

            # cull based on searchterm
            if keep:
                if docolorize:	# only true if searching for a real term
                    if lookfor in acommand.upper() or lookfor in syno.upper():
                        link_text = re.sub(re_searchterm, rer_searchterm_colorize, link_text)
                        syno = re.sub(re_searchterm, rer_searchterm_colorize, syno)
                    else:
                        keep = False

            # cull based on criteria
            if keep:
                if notcriteria:
                    if criteria == "help" and cmd_list[help_idx]:
                        keep = False
                    if criteria == "ques" and cmd_list[ques_idx]:
                        keep = False
                else:
                    if criteria == "help" and not cmd_list[help_idx]:
                        keep = False
                    if criteria == "ques" and not cmd_list[ques_idx]:
                        keep = False

            # highlight internal commands
            if "**" in syno:
                saw_int = True
                syno = color_internal_flag(syno)

            # Define description checkmarksfor this entry
            help_chk = ""
            ques_chk = ""
            if cmd_list[help_idx]:
                help_chk = checkmark
            if cmd_list[ques_idx]:
                ques_chk = checkmark


            # Handle 1st char for letter intro and handle any letter_list cache
            currchar = acommand[0]
            if currchar.isalpha():
                if prevchar != currchar:
                    if len(letter_list) > 1:	# colect what we have accumulated
                        count = len(letter_list) - 1	# not letter intro entry
                        letter_list[0] = letter_list[0] % count	# include count
                        total_count = total_count + count
                        full_list = full_list + letter_list
                    # starting a new letter, note how '%d' also included
                    letter_list = [ "<tr><td id=%s><font size=+3>%s - %s %s</font></td></tr>" % (currchar, currchar, "%d", cnt_type) ]

                    prevchar = currchar

            view_arg = ""
            if view10:
                view_arg = view_arg + "&view10=Y"
            if view11:
                view_arg = view_arg + "&view11=Y"
            
            if keep:
                link = ("/cgi-bin/describeWindows?sysref=%s&proc=y&criteria=%s&not=%s&command=%s" % (sysref, criteria, passon_not, acommand)) + novm_arg + view_arg
                link = ("/cgi-bin/describeWindows?sysref=%s&proc=y&criteria=%s&not=%s&command=%s" % (sysref, criteria, passon_not, acommand)) + novm_arg + view_arg
                link = "<a href=%s>%s</a>" % (link, link_text)

                # remember this
                #               LINK       HELP        QUES    SYNOPSIS
                aline = "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" \
                    % (link, help_chk, ques_chk, syno)
                letter_list.append(aline)
                alpha.add(currchar)	# remember for only what is shown

    # End of loop on entries

    if len(letter_list) > 1:	# get last letter block
        count = len(letter_list) - 1	# not letter intro entry
        letter_list[0] = letter_list[0] % count	# include count
        total_count = total_count + count
        full_list = full_list + letter_list

    # Present local links for leading letters
    width = 26
    pos = 1
    if len(alpha) > 0:
        print("<h2>First letter links:</h2>") # 
    print("<table")
    for c in sorted(alpha):
        if not c.isalpha():
            continue
        if pos == 1:
            print("<tr>")
        if pos > width:
            print("</tr><tr>")
            pos = 1
        print("<td width=34><a href=#%s>%s</a></td>" % (c, c))
        pos = pos + 1
    print("</table>")

    # show what we accumulated in full_list
    searchfor = ""
    if docolorize:
        searchfor = ", searching for %s" % re.sub(re_searchterm, rer_searchterm_colorize, searchterm_string)
        fordesc = "undefined"
    if criteria == "all":
        fordesc = "all"
    elif criteria == "help":
        fordesc = "<i>help command</i>"
    elif criteria == "ques":
        fordesc = "<i>command /?</i>"
    show_not = ""
    if notcriteria:
        show_not = ", excluding"

    print("<h2>%d presented. Origin criteria: %s%s%s.</h2>" % (total_count, fordesc, show_not, searchfor))
    if total_count == 0:
        print("<red><h2>Nothing found</h2></red>")
    else:
        print("<table border=2 width=100%>")
        print(table_header)

        for aline in full_list:	# present what was found:
            print(aline)

        # End the table
        print("</table>")
    if len(full_list) > 0:
        legend = "no legend"
        if saw_int:
            legend = color_internal_flag("<p><br><b><font size=+1>Legend:</b><br>** internal command/task</font>")
        print(legend)
        print("""
        <h2>&bull; <u>Network Description</u> links:</b>
        <br>Many refer to:
        <br><a  target=_blank  href=https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands#command-line-reference-a-z>Windows commands | Microsoft Learn</a>

        <br>&nbsp;&nbsp;&nbsp;&nbsp;(https://learn.microsoft.com/en-us/windows-server/administration/windows-commands)
        <br>Some refer to:
        <br><a target=_blank href=https://ss64.com/nt/>An A-Z Index of Windows CMD commands</a>
        <br>&nbsp;&nbsp;&nbsp;&nbsp;(https://ss64.com/nt/)
        </h2><p>
        <h2>&bull; Many of the HTML descriptions are from Google AI</h2>
        <h2>&bull; Executable files have suffixes of:
        <br><pre>.EXE .BAT .COM .CMD .CPL .VBS .VBE .JS .JSE .WSF .WSH .MSC</pre>
        <h2>
        """)

    exit(0)	# all done with searching

# ============== From here on it is all about showing indidual explainations ======================
# print("<br>Fetching description")

# Even though category and not are passed, there does not seem to be a good reason to trim the
# various descriptions here. Maybe someday but not today.

command = command.upper()
if command[0] != ".":
    command = remove_suffix(command)	# allow entrirs of COMMAND.SUFFIX

if command not in cmd_dict:
    print_back("<h2><red>ERROR: Executable/task '</red>%s<red>' not known.</red></h2>" % command)
    exit(0)

cmd_list = cmd_dict[command]
# print("<br>in description presenting for", command, "criteria", criteria, "cmd_list", cmd_list)
if not (cmd_list[help_idx] or cmd_list[ques_idx] or  cmd_list[html_idx]):
    print("<red><h2>ERROR: There is no description for", command, "</h2></red>")
    exit(0)


if not (cmd_list[help_idx] or cmd_list[ques_idx]  or cmd_list[html_idx]):
    print("<h2><red>ERROR: Command </red> %s <red>exists but no explaination available.</red></h2>" % command)
    exit(0)

print_back(page_header)

# Show single entry table for command description being presented
print("<table border=2 width=100%>")
print(table_header)
desc = cmd_list[syno_idx]
help_chk = ""
ques_chk = ""
if cmd_list[help_idx]:
    help_chk = checkmark
if cmd_list[ques_idx]:
    ques_chk = checkmark
aline = "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" \
    % (command, help_chk, ques_chk, color_internal_flag(desc))
print(aline)
print("</table>")

novm_cache_msg = "<font size=+2><i>No description presented. No VM or Cache.</i></font>"

print("<p><article class=description>")
print("<h1>%s Description</h1>" % command)

if cmd_list[html_idx]:
    file_path = files_html_path_format % command
    print("<h2>&bull; %s</h2>" % file_path)
    if os.path.exists(file_path):
        file = open(file_path, "r")
        lines = file.readlines()
        file.close()
        firstline= True
        for i in range(len(lines)):
            lines[i] = lines[i].rstrip()
            if i == 0:
                if "**" in lines[0]:
                    lines[0] = color_internal_flag(lines[0]) + " (internal command/task)"
            lines[i] = lines[i].replace("(R)", "&reg;")
            lines[i] = lines[i].replace("(C)", "&copy;")
            if firstline:
                firstline = False
                print("<h2><green>", lines[i].rstrip().replace("b>", "u>"), "</green></h2>")
            else:
                # Handle @net(URL) reference for Network Description
                if "@net(" in lines[i]:
                    lines[i] = lines[i].strip()
                    url = re.sub(r"@net\((.*)\)", r"\1", lines[i]).strip()
                    if url == lines[i]:
                        print("<b>SYNTAX ERROR:</b>")
                    else:
                        netdesc = """
                        <a href=%s
                        onclick = 'window.open(this.href, this.href,
                        "location=yes,height=900,width=800,top=10,left=1050,scrollbars=yes,status=yes,toolbar=no");
                        event.preventDefault();
                        ' ;
                        >Network Description</a>
                        """ % url
                        print(netdesc)

                        lines[i] = ""	# Eliminate line as we have replaced it

                # Handle entry reference of the form: @ref(reference)
                while(True):
                    if "@ref(" not in lines[i]:
                        break
                    lines[i] = lines[i].rstrip()
                    locate = re.search(r"@ref\([A-Za-z0-9.;_-]+\)", lines[i])	# get 1st on line
                    try:
                        match = locate.group()
                        inref = re.sub(r"@ref\(([A-Za-z0-9.;_-]+)\)", r"\1", match)
                        lower_ref = inref.lower()
                        upper_ref = remove_suffix(inref)
                        upper_ref = upper_ref.upper()
                        good = True
                        if upper_ref == command:
                            link = "<b>%s[ERR_SELF]</b>" % lower_ref
                            good = False
                        if good and upper_ref not in cmd_dict:
                            link = "<b>%s(ERR_UNDEF]</b>" % lower_ref
                            good = False
                        if good:
                            addsysref = ""
                            if sysref_arg:
                                addsysref = "&sysref=%s" % sysref
                            link = "<a href=http:%s?command=%s%s>%s</a>" % (script_name, upper_ref, addsysref, lower_ref)
                        inreplace = "@ref(" + inref + ")"
                        lines[i] = lines[i].replace(inreplace, link)
                    except:
                        break
                print(lines[i])
        # Indicate the end
        print("<table><tr><td width=290><hr><b>End of %s</b></td></tr></table>" % file_path)
    else:
        print("<red><h2>ERROR: File not found. Was detected earlier?</h2></red>")

if cmd_list[help_idx]:
    print("<h2>&bull; help %s</h2>" % command)
    help_cache = "files/help"	# directory
    help_cache_file = "%s/%s" % (help_cache, command)
    help_lines = []

    if os.path.exists(help_cache_file):
        cache = open(help_cache_file, "r")
        help_lines = cache.readlines()
        cache.close()
    elif novm:
        print(novm_cache_msg)
    else:
        cmd = "cmd /c \"%s  /?\" 2>&1 < /dev/null" % command
        help_lines = runwindowscmd(cmd)
        cache = open(ques_cache_file, "w")
        for line in help_lines:
            line = line.rstrip().replace("<", "&lt;").replace(">", "&gt;")
            cache.write(line.rstrip()+"\n")
        cache.close()

    if help_lines != []:	# have something
        print("<pre>")
        for line in help_lines:
            print(line.rstrip())
        print("</pre>")

if cmd_list[ques_idx]:
    print("<h2>&bull; %s /?</h2>" % command)
    ques_cache = "files/ques"	# directory
    ques_cache_file = "%s/%s" % (ques_cache, command)
    ques_lines = []

    if os.path.exists(ques_cache_file):
        cache = open(ques_cache_file, "r")
        ques_lines = cache.readlines()
        cache.close()
    elif novm:
        print(novm_cache_msg)
    else:
        cmd = "cmd /c \"%s  /?\" 2>&1 < /dev/null" % command
        ques_lines = runwindowscmd(cmd)
        cache = open(ques_cache_file, "w")
        for line in ques_lines:
            line = line.rstrip().replace("<", "&lt;").replace(">", "&gt;")
            cache.write(line.rstrip()+"\n")
        cache.close()

    if ques_lines != []:	# have something
        if cmd_list[help_idx] and help_lines == ques_lines:
            print("The description from this is the same as the description from <b>help</b> above.<p>")
        else:
            print("<pre>")
            for line in ques_lines:
                print(line.rstrip())
            print("</pre>")

print("<p><hr><b>End of description</b>")
print("</article>")

exit(0)	# all done
