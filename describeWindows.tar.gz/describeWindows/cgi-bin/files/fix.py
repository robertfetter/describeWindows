import os
old = "WEB command description"
new = "Network command description"

files = os.listdir(".")
for afile in files:
    if ".html" not in afile:
        continue
    
    f = open(afile, "r")
    lines = f.readlines()
    f.close()
    f = open(afile, "w")
    for aline in lines:
        if old in aline:
            aline = aline.replace(old, new)
        f.write(aline)
    f.close()

