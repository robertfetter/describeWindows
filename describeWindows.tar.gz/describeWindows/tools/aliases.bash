# for running things
alias new=~/describeWindows/tools/newwin
alias old=~/describeWindows/tools/old
alias see=~/describeWindows/tools/see
alias look=~/describeWindows/tools/look
alias net=~/describeWindows/tools/net
alias chk=~/describeWindows/tools/chk
