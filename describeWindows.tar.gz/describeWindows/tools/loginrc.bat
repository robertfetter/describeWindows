@echo off
rem Cuoy to User Login folder (Run shell:startup):
rem C:\Users\robert\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
c:/cygwin64/bin/bash c:/Users/robert/bin/loginrc.bash
pause
