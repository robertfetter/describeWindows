import os
import re
allexe = []
win10 = []
win11 = []
windows_suffix =  ['.COM', '.EXE', '.BAT', '.COM', '.CMD', '.CPL', '.VBS', '.VBE', '.JS', '.JSE', '.WSF', '.WSH', '.MSC'] 
def remove_suffix(name):
    for asuffix in windows_suffix:
        re_pat = "\\" + asuffix + "$"
        regexp = re.compile(re_pat, flags=re.IGNORECASE)
        if regexp.search(name):
            name = re.sub(regexp, "", name)
            break
    return name
win10_lines = open("win10.allexe","r").readlines()
for i in range(len(win10_lines)):
    if "cygwin" in win10_lines[i]:
        continue
    if "firefox" in win10_lines[i]:
        continue
    if "genwin10.bat" in win10_lines[i]:
        continue
    if "genwin11.bat" in win10_lines[i]:
        continue
    
    new = win10_lines[i].replace("\\", "/").upper()
    if "ROBERT/BIN" in new:
        continue
    new = os.path.basename(new).strip()
    new = remove_suffix(new)
    win10.append(new)
win11_lines = open("win11.allexe","r").readlines()
for i in range(len(win11_lines)):
    if "cygwin" in win11_lines[i]:
        continue
    if "firefox" in win11_lines[i]:
        continue
    if "genwin10.bat" in win11_lines[i]:
        continue
    if "genwin11.bat" in win11_lines[i]:
        continue

    new = win11_lines[i].replace("\\", "/").upper()
    if "ROBERT/BIN" in new:
        continue
    new = os.path.basename(new).strip()
    new = remove_suffix(new)
    win11.append(new)
allexe = win10 + win11
allexe = set(allexe)
allexe = list(allexe)
allexe.sort()
files = dict()
dirent = os.scandir("/home/robert/httpd/cgi-bin/files")
for afile in dirent:
    if not afile.is_file():
        continue
    if ".html"  not in afile.name:
        continue
    filecmd = afile.name.replace(".html", "")
    filecmd = filecmd.upper()
    files[filecmd] = True


for aexe in allexe:
    if aexe in files:
        continue
    if aexe in win10 and aexe not in win11:
        loc = "<b>NOT in win11</b>"
    elif aexe in win11 and aexe not in win10:
        loc = "<b>NEW in win11</b>"
    else:
        loc = ""
    print(aexe, aexe.lower(), loc)
