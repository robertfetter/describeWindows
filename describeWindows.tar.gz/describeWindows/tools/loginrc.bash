# bash script run at login time
# launched by loginrc.bat which is itself copyed to the user login folder
# (directory opened on Windows with Run Shell:startup)

windows_hostname=`hostname`
windows_ip_file=$HOME/linux/addr/ip.windows

# Colors
RED="\e[1;31m"
GREEN="\e[1;32m"
RESET="\e[0m"

# bring in useful functions
. $HOME/linux/httpd/cgi-bin/sys.function

# stash our address
windows_ip=`c:/Windows/System32/ipconfig /RENEW |awk '/IPv4/ {print $NF}'|sed -e 's/\r//'`
result=`sys_FileSetAddress windows $windows_ip`
if [ result = "" ]
then
    echo ERROR: Cannot set Windows IP address in `sys_FileGetPath windows`
fi

# learn main system identity and apply to hosts file
linux_hostname=`sys_ConfigGetHostname linux`
result=linux_ip=`sys_HostsApplyEntry linux`
if [ "$result" = "" ]
then
    echo ERROR: Cannot set Linux IP address in `sys_HostsGetPath`
fi

# show addresses
echo -e " $GREEN"
echo $linux_hostname
cat `sys_FileGetPath linux`
echo `hostname`
cat `sys_FileGetPath windows`
echo -e " $RESET"

echo " "

# Clean temporary directories as much as we can to be like Linux/Unix at startup
echo Cleaning temporary files directories.
cygwin_tempdir=c:/cygwin64/tmp
windows_tempdir=C:/Users/robert/AppData/Local/Temp
rm -rf $cygwin_tempdir/* $windows_tempdir/* 2> /dev/null &

echo " "

