import os
import re
dir = "/usr/lib/cgi-bin/files"
os.chdir(dir)
dirent = os.scandir(dir)
files = list()
for afile in dirent:
    if not afile.is_file():
        continue
    if ".html"  not in afile.name:
        continue
    files = files + [ afile.name ]
files.sort()
for afile in files:
    infile = open(afile, "r")
    lines = infile.readlines()
    infile.close()
    # present filename, google search term, @net(URL) for file
    for aline in lines:
        if '<a href="http' in aline:
            url = aline.replace('<a href="', "").replace('"', "").strip()
            entry = afile.replace(".html", "").lower()
            print(afile, "\nwindows syntax", entry, "\n", "@net(%s)" % url, "\n")
