echo on
rem run in administrator cmd.exe window
takeown /f c:\Windows
icacls c:\Windows /grant robert:f
takeown /f c:\Windows\System32
icacls c:\Windows\System32 /grant robert:f
takeown /f c:\Windows\System32\drivers
icacls c:\Windows\System32\drivers /grant robert:f
takeown /f c:\Windows\System32\drivers\etc
icacls c:\Windows\System32\drivers\etc /grant robert:f
takeown /f c:\Windows\System32\drivers\etc\hosts
icacls c:\Windows\System32\drivers\etc\hosts /grant robert:f
