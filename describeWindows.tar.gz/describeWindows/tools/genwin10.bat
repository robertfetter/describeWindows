where *.COM *.EXE *.BAT *.CMD *.CPL *.VBS *.VBE *.JS *.JSE *.WSF *.WSH *.MSC > win10.allexe
